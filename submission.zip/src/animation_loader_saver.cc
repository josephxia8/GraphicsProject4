#include "bone_geometry.h"

/*
 * Placeholder functions for Milestone 2
 */

void Mesh::saveAnimationTo(const std::string& fn)
{
}

void Mesh::loadAnimationFrom(const std::string& fn)
{
}
