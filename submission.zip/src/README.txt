Assignment 5
Amber Smith (as75287) and Joseph Xia (jx2598)

We used a Windows computer to run this.